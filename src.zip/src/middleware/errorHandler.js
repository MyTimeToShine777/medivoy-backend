'use strict';

export const errorHandler = (error, req, res, next) => {
    let statusCode = error.statusCode || 500;
    let message = error.message || 'Internal Server Error';
    let errorCode = 'SERVER_ERROR';

    console.error(`❌ Error Handler [${statusCode}]: ${message}`);

    // Sequelize Validation Error
    if (error.name === 'SequelizeValidationError') {
        statusCode = 400;
        errorCode = 'VALIDATION_ERROR';
        const messages = [];
        if (error.errors && Array.isArray(error.errors)) {
            for (let i = 0; i < error.errors.length; i++) {
                messages.push(error.errors[i].message);
            }
        }
        message = messages.length > 0 ? messages.join(', ') : 'Validation failed';
    }

    // Sequelize Unique Constraint
    if (error.name === 'SequelizeUniqueConstraintError') {
        statusCode = 409;
        errorCode = 'DUPLICATE_ENTRY';
        message = 'Duplicate entry detected';
    }

    // Sequelize Database Error
    if (error.name === 'SequelizeDatabaseError') {
        statusCode = 500;
        errorCode = 'DATABASE_ERROR';
        message = 'Database error occurred';
    }

    // JWT Errors
    if (error.name === 'JsonWebTokenError') {
        statusCode = 401;
        errorCode = 'INVALID_TOKEN';
        message = 'Invalid authentication token';
    }

    if (error.name === 'TokenExpiredError') {
        statusCode = 401;
        errorCode = 'TOKEN_EXPIRED';
        message = 'Authentication token has expired';
    }

    // Mongoose Errors
    if (error.name === 'ValidationError') {
        statusCode = 400;
        errorCode = 'VALIDATION_ERROR';
        const messages = [];
        for (const key in error.errors) {
            if (error.errors.hasOwnProperty(key)) {
                messages.push(error.errors[key].message);
            }
        }
        message = messages.length > 0 ? messages.join(', ') : 'Validation failed';
    }

    if (error.name === 'CastError') {
        statusCode = 400;
        errorCode = 'INVALID_ID';
        message = 'Invalid ID format';
    }

    res.status(statusCode).json({
        success: false,
        message: message,
        code: errorCode,
        timestamp: new Date().toISOString(),
        ...(process.env.NODE_ENV === 'development' && {
            stack: error.stack,
            originalError: error.message
        })
    });
};