'use strict';

export const loggingMiddleware = (req, res, next) => {
    const startTime = Date.now();
    const requestId = req.id || 'unknown';
    const method = req.method;
    const url = req.originalUrl;
    const ip = req.ip || (req.connection && req.connection.remoteAddress) || 'unknown';
    const userId = (req.user && req.user.userId) ? req.user.userId : 'anonymous';
    const userRole = (req.user && req.user.role) ? req.user.role : 'guest';

    res.on('finish', () => {
        const duration = Date.now() - startTime;
        const status = res.statusCode;
        const logMessage = '[' + requestId + '] ' + method + ' ' + url + ' - Status: ' + status + ' - Duration: ' + duration + 'ms - IP: ' + ip + ' - User: ' + userId + ' - Role: ' + userRole;

        if (status >= 500) {
            console.error(`❌ ${logMessage}`);
        } else if (status >= 400) {
            console.warn(`⚠️ ${logMessage}`);
        } else if (status >= 200 && status < 300) {
            console.log(`✅ ${logMessage}`);
        } else {
            console.info(`ℹ️ ${logMessage}`);
        }
    });

    next();
};