'use strict';

import cors from 'cors';

export const corsMiddleware = cors({
    origin: process.env.CORS_ORIGIN ? process.env.CORS_ORIGIN.split(',') : 'http://localhost:3000',
    credentials: process.env.CORS_CREDENTIALS === 'true',
    methods: (process.env.CORS_METHODS || 'GET,POST,PUT,DELETE,PATCH,OPTIONS').split(','),
    allowedHeaders: (process.env.CORS_ALLOW_HEADERS || 'Content-Type,Authorization').split(','),
    exposedHeaders: ['X-Cache', 'X-Request-ID', 'X-RateLimit-Limit', 'X-RateLimit-Remaining'],
    optionsSuccessStatus: 200,
    maxAge: 86400
});