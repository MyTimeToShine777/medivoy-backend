'use strict';

import jwt from 'jsonwebtoken';
import { User } from '../models/index.js';
import { cacheService } from '../config/redis.js';

const ALGORITHM = 'HS256';
const TOKEN_TYPES = {
    ACCESS: 'access',
    REFRESH: 'refresh'
};

export const authenticateToken = async(req, res, next) => {
    try {
        // Extract token
        let token = null;
        const authHeader = req.headers && req.headers.authorization ? req.headers.authorization : null;

        if (authHeader) {
            const headerParts = authHeader.split(' ');
            if (headerParts && headerParts.length === 2 && headerParts[0] === 'Bearer') {
                token = headerParts[1];
            }
        }

        if (!token) {
            if (req.cookies && req.cookies.accessToken) {
                token = req.cookies.accessToken;
            }
        }

        if (!token) {
            console.warn(`❌ No authentication token provided from ${req.ip}`);
            return res.status(401).json({
                success: false,
                message: 'No authentication token provided',
                code: 'NO_AUTH_TOKEN'
            });
        }

        // Verify token
        let decoded = null;
        try {
            decoded = jwt.verify(token, process.env.JWT_SECRET, { algorithms: [ALGORITHM] });
        } catch (jwtError) {
            if (jwtError.name === 'TokenExpiredError') {
                console.warn(`❌ Token expired for user from ${req.ip}`);
                return res.status(401).json({
                    success: false,
                    message: 'Authentication token has expired',
                    code: 'TOKEN_EXPIRED',
                    expiredAt: jwtError.expiredAt
                });
            }

            if (jwtError.name === 'JsonWebTokenError') {
                console.warn(`❌ Invalid JWT token from ${req.ip}`);
                return res.status(401).json({
                    success: false,
                    message: 'Invalid or malformed authentication token',
                    code: 'INVALID_TOKEN'
                });
            }

            throw jwtError;
        }

        if (!decoded) {
            console.warn(`❌ Token decoded is null from ${req.ip}`);
            return res.status(401).json({
                success: false,
                message: 'Failed to decode token',
                code: 'DECODE_FAILED'
            });
        }

        if (!decoded.userId) {
            console.warn(`❌ Token missing userId from ${req.ip}`);
            return res.status(401).json({
                success: false,
                message: 'Token missing required fields',
                code: 'INVALID_TOKEN_PAYLOAD'
            });
        }

        // Check blacklist
        const blacklistKey = 'token_blacklist_' + decoded.userId + '_' + decoded.iat;
        const isBlacklisted = await cacheService.exists(blacklistKey);

        if (isBlacklisted) {
            console.warn(`❌ Blacklisted token used by user ${decoded.userId}`);
            return res.status(401).json({
                success: false,
                message: 'Token has been revoked',
                code: 'TOKEN_REVOKED'
            });
        }

        // Verify user still exists
        const user = await User.findByPk(decoded.userId);
        if (!user) {
            console.warn(`❌ User ${decoded.userId} not found for token`);
            return res.status(401).json({
                success: false,
                message: 'User not found',
                code: 'USER_NOT_FOUND'
            });
        }

        if (!user.isActive) {
            console.warn(`❌ Inactive user ${decoded.userId} attempted access`);
            return res.status(401).json({
                success: false,
                message: 'User account is inactive',
                code: 'USER_INACTIVE'
            });
        }

        req.user = decoded;
        req.userId = decoded.userId;
        req.token = token;
        req.userRole = decoded.role;

        console.log(`✅ Auth successful: User ${decoded.userId} (Role: ${decoded.role})`);
        next();
    } catch (error) {
        console.error(`❌ Authentication error: ${error.message}`);
        return res.status(500).json({
            success: false,
            message: 'Authentication processing failed',
            code: 'AUTH_ERROR'
        });
    }
};

export const authMiddleware = authenticateToken;