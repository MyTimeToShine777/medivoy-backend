'use strict';

export const asyncHandler = (fn) => {
    if (typeof fn !== 'function') {
        throw new Error('asyncHandler: argument must be a function');
    }

    return (req, res, next) => {
        const executionResult = Promise.resolve(fn(req, res, next));

        executionResult.catch((error) => {
            console.error(`❌ Async handler error: ${error.message}`);

            if (error && typeof error === 'object') {
                if (error.statusCode && error.message && error.code) {
                    return next(error);
                }
            }

            const appError = new Error(error.message || 'Unknown error');
            appError.statusCode = 500;
            appError.code = 'ASYNC_ERROR';
            next(appError);
        });
    };
};