'use strict';

import { sequelize } from '../config/database.js';
import { cacheService } from '../config/redis.js';
import { mongoDBService } from '../config/mongodb.js';

export const healthCheckHandler = async(req, res) => {
    try {
        const checks = {
            timestamp: new Date().toISOString(),
            status: 'healthy',
            version: process.env.APP_VERSION || '1.0.0',
            environment: process.env.NODE_ENV,
            services: {
                database: 'disconnected',
                cache: 'disconnected',
                mongodb: 'not_configured'
            }
        };

        // Check PostgreSQL
        try {
            await sequelize.authenticate();
            checks.services.database = 'connected';
        } catch (dbError) {
            console.error(`❌ Database health check failed: ${dbError.message}`);
            checks.services.database = 'disconnected';
            checks.status = 'degraded';
        }

        // Check Redis
        if (cacheService && cacheService.connected) {
            checks.services.cache = 'connected';
        } else {
            checks.services.cache = 'disconnected';
            checks.status = 'degraded';
        }

        // Check MongoDB
        if (mongoDBService && mongoDBService.connected) {
            checks.services.mongodb = 'connected';
        } else {
            checks.services.mongodb = 'not_configured';
        }

        const statusCode = checks.status === 'healthy' ? 200 : 503;
        res.status(statusCode).json(checks);
    } catch (error) {
        console.error(`❌ Health check error: ${error.message}`);
        res.status(500).json({
            status: 'unhealthy',
            error: error.message,
            timestamp: new Date().toISOString()
        });
    }
};