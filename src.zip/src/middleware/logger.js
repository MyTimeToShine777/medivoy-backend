'use strict';

import morgan from 'morgan';
import fs from 'fs';
import path from 'path';
import { dirname } from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(
    import.meta.url);
const __dirname = dirname(__filename);
const logDir = path.join(__dirname, '../../logs');

if (!fs.existsSync(logDir)) {
    try {
        fs.mkdirSync(logDir, { recursive: true });
        console.log(`✅ Log directory created: ${logDir}`);
    } catch (mkdirError) {
        console.error(`❌ Failed to create log directory: ${mkdirError.message}`);
    }
}

const accessLogStream = fs.createWriteStream(path.join(logDir, 'access.log'), { flags: 'a' });
const errorLogStream = fs.createWriteStream(path.join(logDir, 'error.log'), { flags: 'a' });

morgan.token('user-id', (req) => {
    if (req.user && req.user.userId) {
        return req.user.userId;
    }
    return 'anonymous';
});

morgan.token('user-role', (req) => {
    if (req.user && req.user.role) {
        return req.user.role;
    }
    return 'guest';
});

const customFormat = ':remote-addr - :user-id [:user-role] [:date[clf]] ":method :url HTTP/:http-version" :status :res[content-length] ":referrer" ":user-agent" - :response-time ms';

export const requestLogger = morgan(customFormat, {
    stream: accessLogStream,
    skip: function(req, res) {
        return res.statusCode >= 400;
    }
});

export const errorLogger = morgan(customFormat, {
    stream: errorLogStream,
    skip: function(req, res) {
        return res.statusCode < 400;
    }
});