'use strict';

import { User } from '../models/index.js';

export const verifyRoleAccess = (requiredRoles) => {
    return async(req, res, next) => {
        try {
            if (!req.user) {
                return res.status(401).json({
                    success: false,
                    error: 'User not authenticated'
                });
            }

            const user = await User.findByPk(req.user.userId);

            if (!user) {
                return res.status(401).json({
                    success: false,
                    error: 'User not found'
                });
            }

            // Check if user has required role
            if (!requiredRoles.includes(user.role)) {
                return res.status(403).json({
                    success: false,
                    error: 'Insufficient permissions',
                    requiredRoles: requiredRoles,
                    userRole: user.role
                });
            }

            // Attach user to request
            req.user = user;

            next();
        } catch (error) {
            console.error('❌ Role verification error:', error.message);
            return res.status(500).json({
                success: false,
                error: 'Internal server error'
            });
        }
    };
};

export default verifyRoleAccess;