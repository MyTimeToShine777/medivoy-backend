'use strict';

import { cacheService } from '../config/redis.js';

export const cacheMiddleware = (ttl) => {
    if (typeof ttl !== 'number') {
        ttl = 3600;
    }

    if (ttl < 0) {
        ttl = 3600;
    }

    return async(req, res, next) => {
        try {
            // Only cache GET requests
            if (req.method !== 'GET') {
                return next();
            }

            // Skip if nocache param present
            if (req.query && req.query.nocache === 'true') {
                console.log(`⏭️ Cache skipped for: ${req.originalUrl}`);
                return next();
            }

            // Skip if user is authenticated and param says so
            if (req.user && req.query && req.query.skipAuthCache === 'true') {
                return next();
            }

            const cacheKey = 'cache_' + req.originalUrl;

            // Try to get from cache
            let cachedData = null;
            try {
                cachedData = await cacheService.get(cacheKey);
            } catch (cacheError) {
                console.warn(`⚠️ Cache read error: ${cacheError.message}`);
                cachedData = null;
            }

            if (cachedData) {
                console.log(`✅ Cache HIT: ${cacheKey}`);
                res.setHeader('X-Cache', 'HIT');
                res.setHeader('X-Cache-TTL', ttl);
                return res.json(cachedData);
            }

            console.log(`📝 Cache MISS: ${cacheKey}`);
            res.setHeader('X-Cache', 'MISS');

            // Override res.json to cache response
            const originalJson = res.json.bind(res);
            res.json = function(data) {
                if (res.statusCode === 200 && data) {
                    try {
                        cacheService.set(cacheKey, data, ttl);
                        console.log(`✅ Response cached: ${cacheKey} (TTL: ${ttl}s)`);
                    } catch (setCacheError) {
                        console.warn(`⚠️ Failed to cache response: ${setCacheError.message}`);
                    }
                }
                return originalJson(data);
            };

            next();
        } catch (error) {
            console.error(`❌ Cache middleware error: ${error.message}`);
            next();
        }
    };
};