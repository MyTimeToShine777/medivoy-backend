'use strict';

import multer from 'multer';
import path from 'path';
import fs from 'fs';

const uploadDir = process.env.UPLOAD_DIR || './uploads';

if (!fs.existsSync(uploadDir)) {
    try {
        fs.mkdirSync(uploadDir, { recursive: true });
        console.log(`✅ Upload directory created: ${uploadDir}`);
    } catch (mkdirError) {
        console.error(`❌ Failed to create upload directory: ${mkdirError.message}`);
    }
}

const storage = multer.diskStorage({
    destination: function(req, file, cb) {
        cb(null, uploadDir);
    },
    filename: function(req, file, cb) {
        const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
        const ext = path.extname(file.originalname);
        const name = path.basename(file.originalname, ext);
        const filename = name + '-' + uniqueSuffix + ext;
        cb(null, filename);
    }
});

const fileFilter = function(req, file, cb) {
    const allowedMimes = ['image/jpeg', 'image/png', 'image/gif', 'image/webp', 'application/pdf'];
    const mimeType = file.mimetype;

    if (allowedMimes.indexOf(mimeType) !== -1) {
        cb(null, true);
    } else {
        cb(new Error('File type not allowed: ' + mimeType), false);
    }
};

export const uploadMiddleware = multer({
    storage: storage,
    fileFilter: fileFilter,
    limits: {
        fileSize: parseInt(process.env.MAX_FILE_SIZE) || 5242880
    }
});

export const handleUploadError = function(err, req, res, next) {
    if (err instanceof multer.MulterError) {
        if (err.code === 'FILE_TOO_LARGE') {
            return res.status(413).json({
                success: false,
                message: 'File size exceeds maximum allowed size',
                code: 'FILE_TOO_LARGE',
                maxSize: parseInt(process.env.MAX_FILE_SIZE) || 5242880
            });
        }

        if (err.code === 'LIMIT_FILE_COUNT') {
            return res.status(400).json({
                success: false,
                message: 'Too many files uploaded',
                code: 'TOO_MANY_FILES'
            });
        }

        return res.status(400).json({
            success: false,
            message: err.message,
            code: 'UPLOAD_ERROR'
        });
    }

    if (err) {
        return res.status(400).json({
            success: false,
            message: err.message,
            code: 'UPLOAD_ERROR'
        });
    }

    next();
};