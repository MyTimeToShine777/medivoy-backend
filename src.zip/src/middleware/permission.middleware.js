'use strict';

import { User } from '../models/index.js';
import { cacheService } from '../config/redis.js';

export const roleBasedAccessMiddleware = (allowedRoles) => {
    if (!Array.isArray(allowedRoles)) {
        if (typeof allowedRoles === 'string') {
            allowedRoles = [allowedRoles];
        } else {
            allowedRoles = [];
        }
    }

    return async(req, res, next) => {
        try {
            if (!req.user) {
                console.warn(`❌ Role check: No user in request from ${req.ip}`);
                return res.status(401).json({
                    success: false,
                    message: 'User authentication required',
                    code: 'UNAUTHORIZED'
                });
            }

            if (!req.user.userId) {
                console.warn(`❌ Role check: Invalid user data from ${req.ip}`);
                return res.status(401).json({
                    success: false,
                    message: 'Invalid user information',
                    code: 'INVALID_USER_DATA'
                });
            }

            const cacheKey = 'user_role_' + req.user.userId;
            let userRole = null;

            try {
                userRole = await cacheService.get(cacheKey);
            } catch (cacheError) {
                console.warn(`⚠️ Cache error for user role: ${cacheError.message}`);
                userRole = null;
            }

            if (!userRole) {
                // Query database
                const user = await User.findByPk(req.user.userId);

                if (!user) {
                    console.warn(`❌ User ${req.user.userId} not found in database`);
                    return res.status(404).json({
                        success: false,
                        message: 'User not found',
                        code: 'USER_NOT_FOUND'
                    });
                }

                userRole = user.role;

                // Cache role
                try {
                    await cacheService.set(cacheKey, userRole, 86400);
                } catch (setCacheError) {
                    console.warn(`⚠️ Failed to cache user role: ${setCacheError.message}`);
                }
            }

            const roleMatches = allowedRoles.indexOf(userRole) !== -1;

            if (!roleMatches) {
                console.warn(`❌ Access denied: User ${req.user.userId} with role ${userRole} not in allowed roles`);
                return res.status(403).json({
                    success: false,
                    message: 'Your role does not have access to this resource',
                    code: 'FORBIDDEN',
                    userRole: userRole,
                    allowedRoles: allowedRoles
                });
            }

            req.user.role = userRole;
            console.log(`✅ Role-based access granted: ${userRole}`);
            next();
        } catch (error) {
            console.error(`❌ Role-based access error: ${error.message}`);
            return res.status(500).json({
                success: false,
                message: 'Role verification failed',
                code: 'ROLE_CHECK_ERROR'
            });
        }
    };
};

export const roleAccessMiddleware = roleBasedAccessMiddleware;

// Backwards-compatible alias expected by app.js
export const permissionMiddleware = roleBasedAccessMiddleware;