// Minimal role-based access control middleware
// Exports two names for backward compatibility:
// - roleBasedAccessMiddleware(requiredRoles) : main middleware factory
// - roleAccessMiddleware(requiredRoles) : alias for older imports

export function roleBasedAccessMiddleware(requiredRoles = []) {
    // requiredRoles can be a string or array
    const rolesArray = Array.isArray(requiredRoles) ? requiredRoles : [requiredRoles];

    return (req, res, next) => {
        try {
            const user = req.user || req.session ? .user || null;
            if (!user) {
                return res.status(401).json({ success: false, message: 'Authentication required' });
            }

            // Support both user.role (string) and user.roles (array)
            const userRoles = [];
            if (Array.isArray(user.roles)) userRoles.push(...user.roles.map(r => String(r)));
            if (user.role) userRoles.push(String(user.role));

            const hasRole = rolesArray.length === 0 || rolesArray.some(r => userRoles.includes(String(r)));

            if (!hasRole) {
                return res.status(403).json({ success: false, message: 'Forbidden: insufficient role' });
            }

            return next();
        } catch (err) {
            return next(err);
        }
    };
}

// Backwards-compatible alias
export const roleAccessMiddleware = roleBasedAccessMiddleware;

export default roleBasedAccessMiddleware;