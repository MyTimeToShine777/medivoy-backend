'use strict';

import { AppError } from '../utils/errors/AppError.js';

export const errorHandler = (err, req, res, next) => {
    // Log error
    console.error({
        timestamp: new Date(),
        method: req.method,
        path: req.path,
        error: err.message,
        stack: err.stack
    });

    // Handle AppError
    if (err instanceof AppError) {
        return res.status(err.statusCode).json({
            success: false,
            error: err.message,
            code: err.code
        });
    }

    // Handle Validation Errors
    if (err.name === 'ValidationError') {
        return res.status(400).json({
            success: false,
            error: 'Validation failed',
            details: Object.keys(err.errors).map(key => ({
                field: key,
                message: err.errors[key].message
            }))
        });
    }

    // Handle JWT Errors
    if (err.name === 'JsonWebTokenError') {
        return res.status(401).json({
            success: false,
            error: 'Invalid token'
        });
    }

    if (err.name === 'TokenExpiredError') {
        return res.status(401).json({
            success: false,
            error: 'Token expired'
        });
    }

    // Handle Database Errors
    if (err.name === 'SequelizeUniqueConstraintError') {
        return res.status(409).json({
            success: false,
            error: 'Duplicate entry found',
            field: err.errors[0].path
        });
    }

    if (err.name === 'SequelizeValidationError') {
        return res.status(400).json({
            success: false,
            error: 'Validation failed',
            details: err.errors.map(e => ({
                field: e.path,
                message: e.message
            }))
        });
    }

    // Handle Casting Errors
    if (err.name === 'CastError') {
        return res.status(400).json({
            success: false,
            error: 'Invalid data format'
        });
    }

    // Handle File Upload Errors
    if (err.name === 'MulterError') {
        if (err.code === 'FILE_TOO_LARGE') {
            return res.status(413).json({
                success: false,
                error: 'File size exceeds limit'
            });
        }
        if (err.code === 'LIMIT_FILE_COUNT') {
            return res.status(400).json({
                success: false,
                error: 'Too many files uploaded'
            });
        }
        return res.status(400).json({
            success: false,
            error: 'File upload error: ' + err.message
        });
    }

    // Handle 404
    if (err.statusCode === 404) {
        return res.status(404).json({
            success: false,
            error: 'Resource not found'
        });
    }

    // Default error response
    return res.status(err.statusCode || 500).json({
        success: false,
        error: process.env.NODE_ENV === 'production' ? 'Internal server error' : err.message
    });
};

export const asyncHandler = (fn) => {
    return (req, res, next) => {
        Promise.resolve(fn(req, res, next)).catch(next);
    };
};

export const notFoundHandler = (req, res, next) => {
    return res.status(404).json({
        success: false,
        error: 'Route not found',
        path: req.path
    });
};