'use strict';

import { Translation } from '../models/index.js';
import { cacheService } from '../config/redis.js';

const SUPPORTED_LANGUAGES = (process.env.SUPPORTED_LANGUAGES || 'en,hi,ta,te,ml,kn').split(',');
const DEFAULT_LANGUAGE = process.env.DEFAULT_LANGUAGE || 'en';

export const detectLanguage = (req, res, next) => {
    try {
        let language = DEFAULT_LANGUAGE;

        // Priority: Query > Header > Cookie > User Preference > Default
        if (req.query && req.query.language) {
            language = String(req.query.language).toLowerCase();
        } else if (req.headers && req.headers['accept-language']) {
            const langHeader = req.headers['accept-language'];
            const parts = langHeader.split(',');
            if (parts && parts.length > 0) {
                const firstLang = parts[0];
                const dashIdx = firstLang.indexOf('-');
                const langCode = dashIdx !== -1 ? firstLang.substring(0, dashIdx) : firstLang;
                language = langCode.toLowerCase();
            }
        } else if (req.cookies && req.cookies.language) {
            language = String(req.cookies.language).toLowerCase();
        } else if (req.user && req.user.preferredLanguage) {
            language = String(req.user.preferredLanguage).toLowerCase();
        }

        // Validate language
        if (SUPPORTED_LANGUAGES.indexOf(language) === -1) {
            language = DEFAULT_LANGUAGE;
        }

        req.language = language;
        req.locale = language;
        res.setHeader('Content-Language', language);

        console.log(`✅ Language set to: ${language}`);
        next();
    } catch (error) {
        console.error(`❌ Language detection error: ${error.message}`);
        req.language = DEFAULT_LANGUAGE;
        next();
    }
};

export const loadTranslations = async(req, res, next) => {
    try {
        const language = req.language || DEFAULT_LANGUAGE;
        const cacheKey = 'translations_' + language;

        // Try cache first
        let cachedTranslations = null;
        try {
            const cached = await cacheService.get(cacheKey);
            if (cached && typeof cached === 'object') {
                cachedTranslations = cached;
            }
        } catch (cacheError) {
            console.warn(`⚠️ Cache read failed for translations: ${cacheError.message}`);
            cachedTranslations = null;
        }

        if (cachedTranslations) {
            req.translations = cachedTranslations;
            req.t = function(key, defaultValue) {
                if (typeof defaultValue !== 'string') {
                    defaultValue = key;
                }
                const value = cachedTranslations[key];
                return typeof value === 'string' ? value : defaultValue;
            };
            console.log(`✅ Translations loaded from cache: ${language}`);
            return next();
        }

        // Query database
        let translations = [];
        try {
            translations = await Translation.findAll({
                where: {
                    language: language,
                    isActive: true
                },
                attributes: ['key', 'value', 'module'],
                raw: true
            });
        } catch (dbError) {
            console.warn(`⚠️ Database query failed for translations: ${dbError.message}`);
            translations = [];
        }

        const translationMap = {};
        for (let i = 0; i < translations.length; i++) {
            const t = translations[i];
            if (t && t.key && t.value) {
                translationMap[t.key] = t.value;
            }
        }

        // Cache translations
        try {
            await cacheService.set(cacheKey, translationMap, 86400);
            console.log(`✅ Translations cached: ${language} (${Object.keys(translationMap).length} keys)`);
        } catch (setCacheError) {
            console.warn(`⚠️ Failed to cache translations: ${setCacheError.message}`);
        }

        req.translations = translationMap;
        req.t = function(key, defaultValue) {
            if (typeof defaultValue !== 'string') {
                defaultValue = key;
            }
            const value = translationMap[key];
            return typeof value === 'string' ? value : defaultValue;
        };

        next();
    } catch (error) {
        console.error(`❌ Translation loading error: ${error.message}`);
        req.translations = {};
        req.t = function(key, defaultValue) {
            return typeof defaultValue === 'string' ? defaultValue : key;
        };
        next();
    }
};

export const i18nHelper = (req, res, next) => {
    if (res && res.locals) {
        res.locals.t = req.t;
        res.locals.language = req.language;
        res.locals.locale = req.locale;
        res.locals.translations = req.translations;
    }
    next();
};

export const multilingualMiddleware = detectLanguage;