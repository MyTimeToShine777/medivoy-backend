'use strict';

import { User } from '../models/index.js';
import { cacheService } from '../config/redis.js';

export const verifyRoleAccess = (allowedRoles) => {
    if (!Array.isArray(allowedRoles)) {
        allowedRoles = [allowedRoles];
    }

    return async(req, res, next) => {
        try {
            if (!req.user) {
                console.warn(`❌ Authorization check: No user in request from ${req.ip}`);
                return res.status(401).json({
                    success: false,
                    message: 'User not authenticated',
                    code: 'UNAUTHORIZED'
                });
            }

            if (!req.user.userId) {
                console.warn(`❌ Authorization check: Invalid user data from ${req.ip}`);
                return res.status(401).json({
                    success: false,
                    message: 'Invalid user authentication',
                    code: 'INVALID_USER_DATA'
                });
            }

            if (!req.user.role) {
                console.warn(`❌ Authorization check: No role for user ${req.user.userId}`);
                return res.status(403).json({
                    success: false,
                    message: 'User role not found',
                    code: 'NO_ROLE'
                });
            }

            const userRole = req.user.role;
            const roleFound = allowedRoles.indexOf(userRole) !== -1;

            if (!roleFound) {
                console.warn(`❌ Access denied for user ${req.user.userId} with role ${userRole}`);
                return res.status(403).json({
                    success: false,
                    message: 'Insufficient permissions for this resource',
                    code: 'FORBIDDEN',
                    userRole: userRole,
                    allowedRoles: allowedRoles
                });
            }

            console.log(`✅ Authorization granted: User ${req.user.userId} (Role: ${userRole})`);
            next();
        } catch (error) {
            console.error(`❌ Authorization error: ${error.message}`);
            return res.status(500).json({
                success: false,
                message: 'Authorization verification failed',
                code: 'AUTH_CHECK_ERROR'
            });
        }
    };
};

export const authorizationMiddleware = verifyRoleAccess;