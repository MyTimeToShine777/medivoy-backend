'use strict';

export const notFoundHandler = function(req, res) {
    const method = req.method;
    const path = req.path;
    const originalUrl = req.originalUrl;
    const ip = req.ip || (req.connection && req.connection.remoteAddress) || 'unknown';

    console.warn(`⚠️ 404: ${method} ${originalUrl} from ${ip}`);

    res.status(404).json({
        success: false,
        message: 'The requested resource was not found',
        code: 'NOT_FOUND',
        method: method,
        path: path,
        url: originalUrl,
        timestamp: new Date().toISOString(),
        suggestion: 'Please check the API endpoint and try again'
    });
};