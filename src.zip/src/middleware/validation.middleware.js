'use strict';

import { body, validationResult } from 'express-validator';

export const validateLogin = [
    body('email')
    .trim()
    .notEmpty()
    .withMessage('Email is required')
    .isEmail()
    .withMessage('Invalid email format')
    .normalizeEmail(),
    body('password')
    .notEmpty()
    .withMessage('Password is required')
    .isLength({ min: 6 })
    .withMessage('Password must be at least 6 characters'),
    validationMiddleware
];

export const validateRegister = [
    body('email')
    .trim()
    .notEmpty()
    .withMessage('Email is required')
    .isEmail()
    .withMessage('Invalid email format')
    .normalizeEmail(),
    body('password')
    .notEmpty()
    .withMessage('Password is required')
    .isLength({ min: 8 })
    .withMessage('Password must be at least 8 characters')
    .matches(/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])/)
    .withMessage('Password must contain uppercase, lowercase, number, and special character'),
    body('firstName')
    .trim()
    .notEmpty()
    .withMessage('First name is required')
    .isLength({ min: 2, max: 50 })
    .withMessage('First name must be 2-50 characters'),
    body('lastName')
    .trim()
    .notEmpty()
    .withMessage('Last name is required')
    .isLength({ min: 2, max: 50 })
    .withMessage('Last name must be 2-50 characters'),
    body('phone')
    .optional()
    .trim()
    .isMobilePhone()
    .withMessage('Invalid phone number format'),
    validationMiddleware
];

export const validatePagination = [
    body('page')
    .optional()
    .isInt({ min: 1 })
    .withMessage('Page must be a positive integer'),
    body('limit')
    .optional()
    .isInt({ min: 1, max: 100 })
    .withMessage('Limit must be between 1-100'),
    validationMiddleware
];

export function validationMiddleware(req, res, next) {
    const errors = validationResult(req);

    if (!errors.isEmpty()) {
        const errorArray = errors.array();
        console.warn(`⚠️ Validation errors: ${errorArray.length} error(s)`);

        const formattedErrors = [];
        for (let i = 0; i < errorArray.length; i++) {
            formattedErrors.push({
                field: errorArray[i].param,
                message: errorArray[i].msg,
                value: errorArray[i].value
            });
        }

        return res.status(400).json({
            success: false,
            message: 'Request validation failed',
            errors: formattedErrors,
            code: 'VALIDATION_ERROR',
            errorCount: formattedErrors.length
        });
    }

    next();
}