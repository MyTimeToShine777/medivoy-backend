'use strict';

import rateLimit from 'express-rate-limit';

const getClientIp = (req) => {
    if (req.headers && req.headers['x-forwarded-for']) {
        const forwarded = req.headers['x-forwarded-for'];
        const ips = forwarded.split(',');
        return ips && ips[0] ? ips[0].trim() : 'unknown';
    }

    if (req.ip) {
        return req.ip;
    }

    if (req.connection && req.connection.remoteAddress) {
        return req.connection.remoteAddress;
    }

    return 'unknown';
};

const createErrorHandler = (errorMessage, errorCode) => {
    return (req, res) => {
        const clientIp = getClientIp(req);
        console.warn(`⚠️ Rate limit exceeded [${errorCode}] from ${clientIp}`);
        res.status(429).json({
            success: false,
            message: errorMessage,
            code: errorCode,
            retryAfter: req.rateLimit.resetTime
        });
    };
};

export const authRateLimiter = rateLimit({
    windowMs: parseInt(process.env.AUTH_RATE_LIMIT_WINDOW_MS) || 900000,
    max: parseInt(process.env.AUTH_RATE_LIMIT_MAX_REQUESTS) || 5,
    standardHeaders: false,
    legacyHeaders: false,
    keyGenerator: (req) => {
        const email = req.body && req.body.email ? String(req.body.email).toLowerCase() : getClientIp(req);
        return email;
    },
    skip: (req) => {
        return req.path === '/health';
    },
    handler: createErrorHandler('Too many login attempts. Please try again later.', 'AUTH_RATE_LIMIT_EXCEEDED')
});

export const globalRateLimiter = rateLimit({
    windowMs: parseInt(process.env.RATE_LIMIT_WINDOW_MS) || 900000,
    max: parseInt(process.env.RATE_LIMIT_MAX_REQUESTS) || 100,
    standardHeaders: true,
    legacyHeaders: false,
    keyGenerator: (req) => {
        return getClientIp(req);
    },
    skip: (req) => {
        return req.path === '/health' || req.path === '/';
    },
    handler: createErrorHandler('Too many requests. Please try again later.', 'GLOBAL_RATE_LIMIT_EXCEEDED')
});

export const apiRateLimiter = rateLimit({
    windowMs: parseInt(process.env.RATE_LIMIT_WINDOW_MS) || 900000,
    max: parseInt(process.env.RATE_LIMIT_MAX_REQUESTS) || 100,
    standardHeaders: true,
    legacyHeaders: false,
    keyGenerator: (req) => getClientIp(req),
    skip: (req) => req.path === '/health',
    handler: createErrorHandler('API rate limit exceeded.', 'API_RATE_LIMIT_EXCEEDED')
});

export const createRateLimiter = rateLimit({
    windowMs: parseInt(process.env.RATE_LIMIT_WINDOW_MS) || 900000,
    max: 20,
    standardHeaders: false,
    legacyHeaders: false,
    keyGenerator: (req) => getClientIp(req),
    skip: (req) => req.method !== 'POST',
    handler: createErrorHandler('Too many create requests.', 'CREATE_RATE_LIMIT_EXCEEDED')
});

export const uploadRateLimiter = rateLimit({
    windowMs: 3600000,
    max: 10,
    standardHeaders: false,
    legacyHeaders: false,
    keyGenerator: (req) => getClientIp(req),
    skip: (req) => req.method !== 'POST',
    handler: createErrorHandler('Upload limit exceeded.', 'UPLOAD_RATE_LIMIT_EXCEEDED')
});

export const deleteRateLimiter = rateLimit({
    windowMs: 3600000,
    max: 5,
    standardHeaders: false,
    legacyHeaders: false,
    keyGenerator: (req) => getClientIp(req),
    skip: (req) => req.method !== 'DELETE',
    handler: createErrorHandler('Delete operations limited. Please try again later.', 'DELETE_RATE_LIMIT_EXCEEDED')
});

export const searchRateLimiter = rateLimit({
    windowMs: 60000,
    max: 30,
    standardHeaders: false,
    legacyHeaders: false,
    keyGenerator: (req) => getClientIp(req),
    skip: (req) => req.path.indexOf('/search') === -1,
    handler: createErrorHandler('Search rate limit exceeded.', 'SEARCH_RATE_LIMIT_EXCEEDED')
});