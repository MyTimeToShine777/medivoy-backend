'use strict';

import { DataTypes } from 'sequelize';

// ═══════════════════════════════════════════════════════════════════════════════
// TRANSACTION MODEL - ULTRA-COMPREHENSIVE - NO OPTIONAL CHAINING
// Production Ready with Gateway Validation
// ═══════════════════════════════════════════════════════════════════════════════

export default (sequelize) => {
    const Transaction = sequelize.define('Transaction', {
        transactionId: {
            type: DataTypes.UUID,
            defaultValue: DataTypes.UUIDV4,
            primaryKey: true,
            field: 'transaction_id',
            comment: 'Unique transaction identifier'
        },
        paymentId: {
            type: DataTypes.UUID,
            allowNull: false,
            field: 'payment_id',
            references: {
                model: 'payments',
                key: 'payment_id'
            },
            comment: 'Associated payment record'
        },
        bookingId: {
            type: DataTypes.UUID,
            allowNull: true,
            field: 'booking_id',
            references: {
                model: 'bookings',
                key: 'booking_id'
            },
            comment: 'Associated booking'
        },
        userId: {
            type: DataTypes.UUID,
            allowNull: false,
            field: 'user_id',
            references: {
                model: 'users',
                key: 'user_id'
            },
            comment: 'User who made the transaction'
        },
        gateway: {
            type: DataTypes.ENUM('razorpay', 'stripe', 'paypal', 'payu', 'cash', 'bank_transfer', 'upi', 'card', 'wallet', 'other'),
            allowNull: false,
            comment: 'Payment gateway used'
        },
        gatewayTransactionId: {
            type: DataTypes.STRING(255),
            allowNull: true,
            unique: true,
            field: 'gateway_transaction_id',
            comment: 'Gateway reference transaction ID'
        },
        amount: {
            type: DataTypes.DECIMAL(12, 2),
            allowNull: false,
            validate: {
                min: 0
            },
            comment: 'Transaction amount'
        },
        currency: {
            type: DataTypes.STRING(3),
            defaultValue: 'USD',
            allowNull: false,
            comment: 'Currency code'
        },
        status: {
            type: DataTypes.ENUM('pending', 'processing', 'completed', 'failed', 'cancelled', 'refunded', 'partially_refunded'),
            defaultValue: 'pending',
            allowNull: false,
            comment: 'Transaction status'
        },
        transactionType: {
            type: DataTypes.ENUM('payment', 'refund', 'chargeback', 'adjustment', 'fee', 'commission'),
            defaultValue: 'payment',
            field: 'transaction_type',
            comment: 'Type of transaction'
        },
        paymentMethod: {
            type: DataTypes.ENUM('credit_card', 'debit_card', 'upi', 'net_banking', 'wallet', 'cash', 'bank_transfer', 'cheque'),
            allowNull: true,
            field: 'payment_method',
            comment: 'Payment method used'
        },
        cardLast4: {
            type: DataTypes.STRING(4),
            allowNull: true,
            field: 'card_last4',
            comment: 'Last 4 digits of card'
        },
        cardBrand: {
            type: DataTypes.STRING(50),
            allowNull: true,
            field: 'card_brand',
            comment: 'Card brand (Visa, Mastercard, etc)'
        },
        bankName: {
            type: DataTypes.STRING(100),
            allowNull: true,
            field: 'bank_name',
            comment: 'Bank name for bank transfers'
        },
        accountNumber: {
            type: DataTypes.STRING(50),
            allowNull: true,
            field: 'account_number',
            comment: 'Bank account number (masked)'
        },
        upiId: {
            type: DataTypes.STRING(100),
            allowNull: true,
            field: 'upi_id',
            comment: 'UPI ID for UPI payments'
        },
        gatewayResponse: {
            type: DataTypes.JSONB,
            allowNull: true,
            field: 'gateway_response',
            comment: 'Complete gateway response data'
        },
        errorCode: {
            type: DataTypes.STRING(50),
            allowNull: true,
            field: 'error_code',
            comment: 'Error code if transaction failed'
        },
        errorMessage: {
            type: DataTypes.TEXT,
            allowNull: true,
            field: 'error_message',
            comment: 'Error message if transaction failed'
        },
        description: {
            type: DataTypes.TEXT,
            allowNull: true,
            comment: 'Transaction description'
        },
        initiatedAt: {
            type: DataTypes.DATE,
            allowNull: true,
            field: 'initiated_at',
            comment: 'When transaction was initiated'
        },
        completedAt: {
            type: DataTypes.DATE,
            allowNull: true,
            field: 'completed_at',
            comment: 'When transaction was completed'
        },
        failedAt: {
            type: DataTypes.DATE,
            allowNull: true,
            field: 'failed_at',
            comment: 'When transaction failed'
        },
        refundedAt: {
            type: DataTypes.DATE,
            allowNull: true,
            field: 'refunded_at',
            comment: 'When transaction was refunded'
        },
        refundAmount: {
            type: DataTypes.DECIMAL(12, 2),
            allowNull: true,
            defaultValue: 0.00,
            field: 'refund_amount',
            comment: 'Amount refunded'
        },
        refundReason: {
            type: DataTypes.TEXT,
            allowNull: true,
            field: 'refund_reason',
            comment: 'Reason for refund'
        },
        fees: {
            type: DataTypes.DECIMAL(12, 2),
            allowNull: true,
            defaultValue: 0.00,
            comment: 'Transaction fees charged'
        },
        tax: {
            type: DataTypes.DECIMAL(12, 2),
            allowNull: true,
            defaultValue: 0.00,
            comment: 'Tax amount'
        },
        netAmount: {
            type: DataTypes.DECIMAL(12, 2),
            allowNull: true,
            field: 'net_amount',
            comment: 'Net amount after fees and tax'
        },
        ipAddress: {
            type: DataTypes.STRING(45),
            allowNull: true,
            field: 'ip_address',
            comment: 'IP address of transaction origin'
        },
        userAgent: {
            type: DataTypes.TEXT,
            allowNull: true,
            field: 'user_agent',
            comment: 'Browser user agent'
        },
        deviceType: {
            type: DataTypes.ENUM('mobile', 'tablet', 'desktop', 'unknown'),
            allowNull: true,
            field: 'device_type',
            comment: 'Device type used'
        },
        isTest: {
            type: DataTypes.BOOLEAN,
            defaultValue: false,
            field: 'is_test',
            comment: 'Whether this is a test transaction'
        },
        metadata: {
            type: DataTypes.JSONB,
            allowNull: true,
            comment: 'Additional metadata'
        },
        notes: {
            type: DataTypes.TEXT,
            allowNull: true,
            comment: 'Internal notes'
        }
    }, {
        tableName: 'transactions',
        timestamps: true,
        underscored: true,
        indexes: [{
                fields: ['payment_id']
            },
            {
                fields: ['booking_id']
            },
            {
                fields: ['user_id']
            },
            {
                fields: ['gateway']
            },
            {
                unique: true,
                fields: ['gateway_transaction_id']
            },
            {
                fields: ['status']
            },
            {
                fields: ['transaction_type']
            },
            {
                fields: ['initiated_at']
            },
            {
                fields: ['completed_at']
            }
        ],
        comment: 'Payment transaction records'
    });

    // ═══════════════════════════════════════════════════════════════════════════════
    // HOOKS - GATEWAY VALIDATION & BUSINESS LOGIC
    // ═══════════════════════════════════════════════════════════════════════════════

    // Validate gateway transaction ID for non-cash payments
    Transaction.addHook('beforeCreate', (transaction) => {
        if (transaction.gateway !== 'cash' && !transaction.gatewayTransactionId) {
            throw new Error('Gateway transaction ID is required for non-cash payments');
        }

        if (transaction.amount <= 0) {
            throw new Error('Transaction amount must be positive');
        }

        transaction.initiatedAt = new Date();
    });

    // Auto-set completion timestamp
    Transaction.addHook('beforeUpdate', (transaction) => {
        if (transaction.changed('status')) {
            if (transaction.status === 'completed') {
                transaction.completedAt = new Date();
            } else if (transaction.status === 'failed' || transaction.status === 'cancelled') {
                transaction.failedAt = new Date();
            } else if (transaction.status === 'refunded' || transaction.status === 'partially_refunded') {
                transaction.refundedAt = new Date();
            }
        }
    });

    // Calculate net amount
    Transaction.addHook('beforeSave', (transaction) => {
        const amount = parseFloat(transaction.amount) || 0;
        const fees = parseFloat(transaction.fees) || 0;
        const tax = parseFloat(transaction.tax) || 0;

        transaction.netAmount = amount - fees - tax;
    });

    // Validate refund amount
    Transaction.addHook('beforeSave', (transaction) => {
        if (transaction.refundAmount && transaction.refundAmount > transaction.amount) {
            throw new Error('Refund amount cannot exceed transaction amount');
        }
    });

    // ═══════════════════════════════════════════════════════════════════════════════
    // ASSOCIATIONS
    // ═══════════════════════════════════════════════════════════════════════════════

    Transaction.associate = (models) => {
        Transaction.belongsTo(models.Payment, {
            foreignKey: 'paymentId',
            as: 'payment'
        });

        Transaction.belongsTo(models.Booking, {
            foreignKey: 'bookingId',
            as: 'booking'
        });

        Transaction.belongsTo(models.User, {
            foreignKey: 'userId',
            as: 'user'
        });
    };

    return Transaction;
};