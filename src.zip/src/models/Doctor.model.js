'use strict';

import { DataTypes } from 'sequelize';

// ═══════════════════════════════════════════════════════════════════════════════
// DOCTOR MODEL - ULTRA-COMPREHENSIVE - NO OPTIONAL CHAINING
// Production Ready with Full Validation Hooks
// ═══════════════════════════════════════════════════════════════════════════════

export default (sequelize) => {
    const Doctor = sequelize.define('Doctor', {
        doctorId: {
            type: DataTypes.UUID,
            defaultValue: DataTypes.UUIDV4,
            primaryKey: true,
            field: 'doctor_id',
            comment: 'Unique doctor identifier'
        },

        // ========== RELATIONSHIPS ==========
        hospitalId: {
            type: DataTypes.UUID,
            allowNull: false,
            field: 'hospital_id',
            references: {
                model: 'hospitals',
                key: 'hospital_id'
            },
            index: true,
            comment: 'Hospital this doctor works at'
        },
        userId: {
            type: DataTypes.UUID,
            allowNull: true,
            field: 'user_id',
            references: {
                model: 'users',
                key: 'user_id'
            },
            comment: 'Linked user account (if registered)'
        },
        departmentId: {
            type: DataTypes.UUID,
            allowNull: true,
            field: 'department_id',
            references: {
                model: 'departments',
                key: 'department_id'
            },
            comment: 'Department affiliation'
        },

        // ========== PERSONAL INFORMATION ==========
        firstName: {
            type: DataTypes.STRING(50),
            allowNull: false,
            field: 'first_name',
            validate: {
                len: {
                    args: [2, 50],
                    msg: 'First name must be between 2 and 50 characters'
                },
                notEmpty: {
                    msg: 'First name cannot be empty'
                }
            },
            comment: 'Doctor first name'
        },
        lastName: {
            type: DataTypes.STRING(50),
            allowNull: false,
            field: 'last_name',
            validate: {
                len: {
                    args: [2, 50],
                    msg: 'Last name must be between 2 and 50 characters'
                }
            },
            comment: 'Doctor last name'
        },
        middleName: {
            type: DataTypes.STRING(50),
            allowNull: true,
            field: 'middle_name'
        },
        dateOfBirth: {
            type: DataTypes.DATE,
            allowNull: true,
            field: 'date_of_birth',
            validate: {
                isBefore: new Date().toISOString().split('T')[0]
            }
        },
        gender: {
            type: DataTypes.ENUM('male', 'female', 'other'),
            allowNull: true
        },
        profilePicture: {
            type: DataTypes.TEXT,
            allowNull: true,
            field: 'profile_picture',
            comment: 'URL to doctor profile picture'
        },
        bio: {
            type: DataTypes.TEXT,
            allowNull: true,
            validate: {
                len: {
                    args: [0, 1000],
                    msg: 'Bio must not exceed 1000 characters'
                }
            },
            comment: 'Doctor biography'
        },

        // ========== CONTACT INFORMATION ==========
        email: {
            type: DataTypes.STRING(255),
            allowNull: false,
            unique: {
                msg: 'Email already registered'
            },
            validate: {
                isEmail: {
                    msg: 'Must be a valid email address'
                }
            },
            comment: 'Doctor email address'
        },
        phone: {
            type: DataTypes.STRING(20),
            allowNull: true,
            validate: {
                is: {
                    args: /^[+]?[0-9]{10,15}$/,
                    msg: 'Invalid phone number format'
                }
            }
        },
        mobilePhone: {
            type: DataTypes.STRING(20),
            allowNull: true,
            field: 'mobile_phone'
        },
        officePhone: {
            type: DataTypes.STRING(20),
            allowNull: true,
            field: 'office_phone'
        },

        // ========== PROFESSIONAL QUALIFICATIONS ==========
        qualification: {
            type: DataTypes.STRING(100),
            allowNull: true,
            validate: {
                len: {
                    args: [2, 100],
                    msg: 'Qualification must be between 2 and 100 characters'
                }
            },
            comment: 'e.g., MBBS, MD, DM, PhD'
        },
        qualifications: {
            type: DataTypes.JSONB,
            allowNull: true,
            defaultValue: [],
            comment: 'Array of detailed qualifications with year and institution'
        },
        specialization: {
            type: DataTypes.STRING(100),
            allowNull: true,
            validate: {
                len: {
                    args: [2, 100],
                    msg: 'Specialization must be between 2 and 100 characters'
                }
            },
            comment: 'Main specialization'
        },
        specializations: {
            type: DataTypes.JSONB,
            allowNull: true,
            defaultValue: [],
            comment: 'Array of specializations'
        },
        subSpecialization: {
            type: DataTypes.STRING(100),
            allowNull: true,
            field: 'sub_specialization',
            comment: 'Secondary specialization'
        },
        subSpecializations: {
            type: DataTypes.JSONB,
            allowNull: true,
            defaultValue: [],
            field: 'sub_specializations'
        },

        // ========== PROFESSIONAL CREDENTIALS ==========
        registrationNumber: {
            type: DataTypes.STRING(100),
            unique: {
                msg: 'Registration number already exists'
            },
            allowNull: true,
            field: 'registration_number',
            comment: 'Medical council registration number'
        },
        registrationCouncil: {
            type: DataTypes.STRING(100),
            allowNull: true,
            field: 'registration_council',
            comment: 'e.g., GMC, NMC, etc'
        },
        registrationExpiry: {
            type: DataTypes.DATE,
            allowNull: true,
            field: 'registration_expiry'
        },
        licenseNumber: {
            type: DataTypes.STRING(100),
            allowNull: true,
            field: 'license_number'
        },
        licenseExpiry: {
            type: DataTypes.DATE,
            allowNull: true,
            field: 'license_expiry',
            comment: 'Medical license expiration date'
        },
        licenseDocumentUrl: {
            type: DataTypes.TEXT,
            allowNull: true,
            field: 'license_document_url'
        },

        // ========== EXPERIENCE ==========
        yearsOfExperience: {
            type: DataTypes.INTEGER,
            allowNull: true,
            field: 'years_of_experience',
            validate: {
                min: 0,
                max: 100
            },
            comment: 'Total years of medical practice'
        },
        experienceDetails: {
            type: DataTypes.JSONB,
            allowNull: true,
            defaultValue: [],
            field: 'experience_details',
            comment: 'Detailed employment history'
        },
        previousHospitals: {
            type: DataTypes.JSONB,
            allowNull: true,
            defaultValue: [],
            field: 'previous_hospitals',
            comment: 'List of previous hospital affiliations'
        },
        joinDate: {
            type: DataTypes.DATE,
            allowNull: true,
            field: 'join_date',
            comment: 'When doctor joined this hospital'
        },

        // ========== CERTIFICATIONS & TRAINING ==========
        certifications: {
            type: DataTypes.JSONB,
            allowNull: true,
            defaultValue: [],
            comment: 'Array of certifications with dates'
        },
        trainingPrograms: {
            type: DataTypes.JSONB,
            allowNull: true,
            defaultValue: [],
            field: 'training_programs',
            comment: 'Training programs attended'
        },
        publications: {
            type: DataTypes.JSONB,
            allowNull: true,
            defaultValue: [],
            comment: 'Research publications'
        },
        awards: {
            type: DataTypes.JSONB,
            allowNull: true,
            defaultValue: [],
            comment: 'Medical awards and recognitions'
        },

        // ========== CONSULTATION DETAILS ==========
        consultationFee: {
            type: DataTypes.DECIMAL(10, 2),
            allowNull: true,
            field: 'consultation_fee',
            validate: {
                min: 0
            },
            comment: 'Fee for expert consultation'
        },
        consultationDuration: {
            type: DataTypes.INTEGER,
            defaultValue: 30,
            field: 'consultation_duration',
            validate: {
                min: 15,
                max: 120
            },
            comment: 'Standard consultation duration in minutes'
        },
        availableForConsultation: {
            type: DataTypes.BOOLEAN,
            defaultValue: true,
            field: 'available_for_consultation'
        },
        consultationTypes: {
            type: DataTypes.JSONB,
            allowNull: true,
            defaultValue: ['video', 'phone'],
            field: 'consultation_types',
            comment: 'Types of consultation available'
        },

        // ========== LANGUAGES ==========
        languages: {
            type: DataTypes.JSONB,
            allowNull: true,
            defaultValue: ['english', 'hindi'],
            comment: 'Languages doctor speaks'
        },
        fluencyLevel: {
            type: DataTypes.JSONB,
            allowNull: true,
            defaultValue: {},
            field: 'fluency_level',
            comment: 'Fluency level for each language (beginner/intermediate/fluent/native)'
        },

        // ========== STATISTICS & PERFORMANCE ==========
        totalExpertCalls: {
            type: DataTypes.INTEGER,
            defaultValue: 0,
            field: 'total_expert_calls',
            comment: 'Total number of consultations completed'
        },
        totalBookings: {
            type: DataTypes.INTEGER,
            defaultValue: 0,
            field: 'total_bookings'
        },
        completedBookings: {
            type: DataTypes.INTEGER,
            defaultValue: 0,
            field: 'completed_bookings'
        },
        averageRating: {
            type: DataTypes.DECIMAL(3, 2),
            defaultValue: 0.0,
            field: 'average_rating',
            validate: {
                min: 0,
                max: 5
            }
        },
        totalReviews: {
            type: DataTypes.INTEGER,
            defaultValue: 0,
            field: 'total_reviews'
        },
        responseTime: {
            type: DataTypes.INTEGER,
            allowNull: true,
            field: 'response_time',
            comment: 'Average response time in minutes'
        },
        cancellationRate: {
            type: DataTypes.DECIMAL(5, 2),
            allowNull: true,
            field: 'cancellation_rate',
            comment: 'Cancellation percentage'
        },

        // ========== SPECIALIZATIONS & EXPERTISE ==========
        treatmentSpecialties: {
            type: DataTypes.JSONB,
            allowNull: true,
            defaultValue: [],
            field: 'treatment_specialties',
            comment: 'Array of treatments doctor specializes in'
        },
        proceduresPerformed: {
            type: DataTypes.JSONB,
            allowNull: true,
            defaultValue: [],
            field: 'procedures_performed',
            comment: 'Procedures the doctor performs'
        },
        successRate: {
            type: DataTypes.DECIMAL(5, 2),
            allowNull: true,
            field: 'success_rate',
            validate: {
                min: 0,
                max: 100
            },
            comment: 'Treatment success rate %'
        },
        complicationRate: {
            type: DataTypes.DECIMAL(5, 2),
            allowNull: true,
            field: 'complication_rate',
            comment: 'Complication rate %'
        },

        // ========== AVAILABILITY & SCHEDULING ==========
        workingDays: {
            type: DataTypes.JSONB,
            allowNull: true,
            defaultValue: ['monday', 'tuesday', 'wednesday', 'thursday', 'friday'],
            field: 'working_days',
            comment: 'Days doctor works'
        },
        workingHours: {
            type: DataTypes.JSONB,
            allowNull: true,
            defaultValue: {
                start: '09:00',
                end: '18:00'
            },
            field: 'working_hours'
        },
        timeZone: {
            type: DataTypes.STRING(50),
            allowNull: true,
            defaultValue: 'UTC',
            field: 'time_zone'
        },
        holidays: {
            type: DataTypes.JSONB,
            allowNull: true,
            defaultValue: [],
            comment: 'Leave dates and holidays'
        },

        // ========== MEDIA & VERIFICATION ==========
        isVerified: {
            type: DataTypes.BOOLEAN,
            defaultValue: false,
            field: 'is_verified',
            index: true,
            comment: 'Doctor verification status'
        },
        verificationStatus: {
            type: DataTypes.ENUM('pending', 'verified', 'rejected'),
            defaultValue: 'pending',
            field: 'verification_status'
        },
        verificationDate: {
            type: DataTypes.DATE,
            allowNull: true,
            field: 'verification_date'
        },
        verificationDocuments: {
            type: DataTypes.JSONB,
            allowNull: true,
            defaultValue: [],
            field: 'verification_documents',
            comment: 'Verification document URLs'
        },
        isFeatured: {
            type: DataTypes.BOOLEAN,
            defaultValue: false,
            field: 'is_featured',
            index: true
        },
        featuredUntil: {
            type: DataTypes.DATE,
            allowNull: true,
            field: 'featured_until'
        },

        // ========== STATUS & ACCOUNT ==========
        isActive: {
            type: DataTypes.BOOLEAN,
            defaultValue: true,
            field: 'is_active',
            index: true
        },
        isSuspended: {
            type: DataTypes.BOOLEAN,
            defaultValue: false,
            field: 'is_suspended'
        },
        suspensionReason: {
            type: DataTypes.TEXT,
            allowNull: true,
            field: 'suspension_reason'
        },
        suspendedAt: {
            type: DataTypes.DATE,
            allowNull: true,
            field: 'suspended_at'
        },
        suspendedUntil: {
            type: DataTypes.DATE,
            allowNull: true,
            field: 'suspended_until'
        },

        // ========== METADATA ==========
        internalNotes: {
            type: DataTypes.TEXT,
            allowNull: true,
            field: 'internal_notes',
            comment: 'Hospital admin notes'
        },
        tags: {
            type: DataTypes.JSONB,
            allowNull: true,
            defaultValue: []
        },
        displayOrder: {
            type: DataTypes.INTEGER,
            defaultValue: 0,
            field: 'display_order'
        },
        lastActivityAt: {
            type: DataTypes.DATE,
            allowNull: true,
            field: 'last_activity_at'
        }
    }, {
        timestamps: true,
        tableName: 'doctors',
        underscored: true,
        indexes: [
            { fields: ['hospital_id'] },
            { fields: ['user_id'] },
            { fields: ['specialization'] },
            { fields: ['is_active'] },
            { fields: ['is_verified'] },
            { fields: ['is_featured'] },
            { unique: true, fields: ['registration_number'] },
            { unique: true, fields: ['email'] },
            { fields: ['average_rating'] },
            { fields: ['years_of_experience'] }
        ],
        scopes: {
            active: {
                where: { isActive: true, isSuspended: false }
            },
            verified: {
                where: { isVerified: true }
            },
            featured: {
                where: { isFeatured: true }
            }
        }
    });

    // ═══════════════════════════════════════════════════════════════════════════════
    // HOOKS - VALIDATION & BUSINESS LOGIC
    // ═══════════════════════════════════════════════════════════════════════════════

    // Validate qualifications before save
    Doctor.addHook('beforeSave', (doctor) => {
        if (!doctor.qualification && (!doctor.qualifications || doctor.qualifications.length === 0)) {
            throw new Error('Doctor must have at least one qualification');
        }

        if (doctor.email && !doctor.email.includes('@')) {
            throw new Error('Invalid email format');
        }

        if (doctor.yearsOfExperience && (doctor.yearsOfExperience < 0 || doctor.yearsOfExperience > 100)) {
            throw new Error('Experience must be between 0 and 100 years');
        }

        if (doctor.consultationFee && doctor.consultationFee < 0) {
            throw new Error('Consultation fee cannot be negative');
        }

        if (doctor.averageRating && (doctor.averageRating < 0 || doctor.averageRating > 5)) {
            throw new Error('Rating must be between 0 and 5');
        }
    });

    // Check license expiry
    Doctor.addHook('beforeSave', (doctor) => {
        if (doctor.licenseExpiry) {
            const expiryDate = new Date(doctor.licenseExpiry);
            const today = new Date();

            if (expiryDate < today) {
                doctor.isVerified = false;
                doctor.verificationStatus = 'rejected';
                console.warn(`Doctor license expired: ${doctor.licenseNumber}`);
            }
        }

        if (doctor.registrationExpiry) {
            const expiryDate = new Date(doctor.registrationExpiry);
            const today = new Date();

            if (expiryDate < today) {
                doctor.isActive = false;
                console.warn(`Doctor registration expired: ${doctor.registrationNumber}`);
            }
        }
    });

    // Update last activity timestamp
    Doctor.addHook('beforeUpdate', (doctor) => {
        if (doctor.changed('totalExpertCalls') || doctor.changed('totalBookings')) {
            doctor.lastActivityAt = new Date();
        }
    });

    // ═══════════════════════════════════════════════════════════════════════════════
    // INSTANCE METHODS
    // ═══════════════════════════════════════════════════════════════════════════════

    Doctor.prototype.getFullName = function() {
        const middle = this.middleName ? ` ${this.middleName}` : '';
        return `${this.firstName}${middle} ${this.lastName}`;
    };

    Doctor.prototype.getAge = function() {
        if (!this.dateOfBirth) return null;
        const today = new Date();
        let age = today.getFullYear() - this.dateOfBirth.getFullYear();
        const monthDiff = today.getMonth() - this.dateOfBirth.getMonth();
        if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < this.dateOfBirth.getDate())) {
            age--;
        }
        return age;
    };

    Doctor.prototype.getExperienceLevel = function() {
        if (!this.yearsOfExperience) return 'Unknown';
        if (this.yearsOfExperience < 2) return 'Fresher';
        if (this.yearsOfExperience < 5) return 'Junior';
        if (this.yearsOfExperience < 10) return 'Mid-Level';
        if (this.yearsOfExperience < 20) return 'Senior';
        return 'Expert';
    };

    Doctor.prototype.isAvailableForConsultation = function() {
        return this.availableForConsultation && this.isActive && !this.isSuspended;
    };

    Doctor.prototype.canConsult = function(treatmentType) {
        return this.treatmentSpecialties && this.treatmentSpecialties.includes(treatmentType) && this.isAvailableForConsultation();
    };

    Doctor.prototype.getConsultationFee = function() {
        return {
            amount: this.consultationFee,
            duration: this.consultationDuration,
            types: this.consultationTypes
        };
    };

    Doctor.prototype.getRating = function() {
        if (this.totalReviews === 0) return null;
        return {
            rating: this.averageRating,
            reviewCount: this.totalReviews,
            percentage: this.totalReviews > 0 ? ((this.totalReviews / this.totalExpertCalls) * 100).toFixed(2) : 0
        };
    };

    Doctor.prototype.getPerformanceMetrics = function() {
        return {
            totalConsultations: this.totalExpertCalls,
            completedBookings: this.completedBookings,
            averageRating: this.averageRating,
            totalReviews: this.totalReviews,
            responseTime: this.responseTime,
            cancellationRate: this.cancellationRate,
            successRate: this.successRate
        };
    };

    Doctor.prototype.isCertificateExpired = function() {
        if (!this.licenseExpiry) return false;
        return new Date(this.licenseExpiry) < new Date();
    };

    Doctor.prototype.getDaysUntilExpiry = function() {
        if (!this.licenseExpiry) return null;
        const today = new Date();
        const expiry = new Date(this.licenseExpiry);
        const diffTime = expiry - today;
        const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
        return diffDays;
    };

    // ═══════════════════════════════════════════════════════════════════════════════
    // CLASS METHODS
    // ═══════════════════════════════════════════════════════════════════════════════

    Doctor.findBySpecialization = async function(specialization) {
        return this.findAll({
            where: { specialization },
            scope: ['active', 'verified']
        });
    };

    Doctor.findTopRatedDoctors = async function(limit = 10) {
        return this.findAll({
            scope: ['active'],
            order: [
                ['averageRating', 'DESC']
            ],
            limit
        });
    };

    // ═══════════════════════════════════════════════════════════════════════════════
    // ASSOCIATIONS
    // ═══════════════════════════════════════════════════════════════════════════════

    Doctor.associate = (models) => {
        Doctor.belongsTo(models.Hospital, { foreignKey: 'hospitalId', as: 'hospital' });
        Doctor.belongsTo(models.User, { foreignKey: 'userId', as: 'account' });
        Doctor.belongsTo(models.Department, { foreignKey: 'departmentId', as: 'department' });
        Doctor.hasMany(models.ExpertCall, { foreignKey: 'expertId', as: 'expertCalls' });
        Doctor.hasMany(models.DoctorSchedule, { foreignKey: 'doctorId', as: 'schedules' });
        Doctor.hasMany(models.Appointment, { foreignKey: 'doctorId', as: 'appointments' });
    };

    return Doctor;
};