'use strict';

import { DataTypes } from 'sequelize';

// ═══════════════════════════════════════════════════════════════════════════════
// BOOKING MODEL - ULTRA-COMPREHENSIVE - NO OPTIONAL CHAINING
// Production Ready with Status Validation
// ═══════════════════════════════════════════════════════════════════════════════

export default (sequelize) => {
    const Booking = sequelize.define('Booking', {
        bookingId: {
            type: DataTypes.UUID,
            defaultValue: DataTypes.UUIDV4,
            primaryKey: true,
            field: 'booking_id'
        },
        userId: {
            type: DataTypes.UUID,
            allowNull: false,
            field: 'user_id',
            references: {
                model: 'users',
                key: 'user_id'
            }
        },
        hospitalId: {
            type: DataTypes.UUID,
            allowNull: false,
            field: 'hospital_id',
            references: {
                model: 'hospitals',
                key: 'hospital_id'
            }
        },
        treatmentId: {
            type: DataTypes.UUID,
            allowNull: false,
            field: 'treatment_id',
            references: {
                model: 'treatments',
                key: 'treatment_id'
            }
        },
        packageId: {
            type: DataTypes.UUID,
            allowNull: true,
            field: 'package_id',
            references: {
                model: 'packages',
                key: 'package_id'
            }
        },
        bookingDate: {
            type: DataTypes.DATE,
            allowNull: false,
            defaultValue: DataTypes.NOW,
            field: 'booking_date'
        },
        preferredDate: {
            type: DataTypes.DATE,
            allowNull: true,
            field: 'preferred_date'
        },
        actualDate: {
            type: DataTypes.DATE,
            allowNull: true,
            field: 'actual_date'
        },
        status: {
            type: DataTypes.ENUM(
                'pending',
                'confirmed',
                'in_progress',
                'completed',
                'cancelled',
                'rejected'
            ),
            defaultValue: 'pending',
            allowNull: false,
            comment: 'Current booking status'
        },
        paymentStatus: {
            type: DataTypes.ENUM('pending', 'partial', 'paid', 'refunded', 'failed'),
            defaultValue: 'pending',
            allowNull: false,
            field: 'payment_status'
        },
        totalAmount: {
            type: DataTypes.DECIMAL(12, 2),
            allowNull: false,
            defaultValue: 0.00,
            field: 'total_amount',
            validate: {
                min: 0
            }
        },
        paidAmount: {
            type: DataTypes.DECIMAL(12, 2),
            defaultValue: 0.00,
            field: 'paid_amount',
            validate: {
                min: 0
            }
        },
        currency: {
            type: DataTypes.STRING(3),
            defaultValue: 'USD',
            allowNull: false
        },
        patientName: {
            type: DataTypes.STRING(100),
            allowNull: false,
            field: 'patient_name'
        },
        patientAge: {
            type: DataTypes.INTEGER,
            allowNull: false,
            field: 'patient_age',
            validate: {
                min: 0,
                max: 150
            }
        },
        patientSex: {
            type: DataTypes.ENUM('male', 'female', 'other'),
            allowNull: false,
            field: 'patient_sex'
        },
        patientCity: {
            type: DataTypes.STRING(100),
            allowNull: true,
            field: 'patient_city'
        },
        patientCountry: {
            type: DataTypes.STRING(100),
            allowNull: true,
            field: 'patient_country'
        },
        patientEmail: {
            type: DataTypes.STRING(255),
            allowNull: false,
            field: 'patient_email',
            validate: {
                isEmail: true
            }
        },
        patientPhone: {
            type: DataTypes.STRING(20),
            allowNull: false,
            field: 'patient_phone'
        },
        hasInsurance: {
            type: DataTypes.BOOLEAN,
            defaultValue: false,
            field: 'has_insurance'
        },
        insuranceProvider: {
            type: DataTypes.STRING(255),
            allowNull: true,
            field: 'insurance_provider'
        },
        insurancePolicyNumber: {
            type: DataTypes.STRING(100),
            allowNull: true,
            field: 'insurance_policy_number'
        },
        comorbidConditions: {
            type: DataTypes.JSONB,
            allowNull: true,
            defaultValue: [],
            field: 'comorbid_conditions',
            comment: 'Array of patient comorbid conditions'
        },
        requiresTravel: {
            type: DataTypes.BOOLEAN,
            defaultValue: false,
            field: 'requires_travel'
        },
        requiresAccommodation: {
            type: DataTypes.BOOLEAN,
            defaultValue: false,
            field: 'requires_accommodation'
        },
        accommodationType: {
            type: DataTypes.ENUM('standard', 'luxury', 'suite', 'none'),
            defaultValue: 'standard',
            field: 'accommodation_type'
        },
        travelDetails: {
            type: DataTypes.JSONB,
            allowNull: true,
            field: 'travel_details',
            comment: 'Flight, transport details'
        },
        accommodationDetails: {
            type: DataTypes.JSONB,
            allowNull: true,
            field: 'accommodation_details',
            comment: 'Hotel, stay details'
        },
        selectedAddOns: {
            type: DataTypes.JSONB,
            allowNull: true,
            defaultValue: [],
            field: 'selected_add_ons',
            comment: 'Additional services selected'
        },
        estimatedCostMin: {
            type: DataTypes.DECIMAL(12, 2),
            allowNull: true,
            field: 'estimated_cost_min'
        },
        estimatedCostMax: {
            type: DataTypes.DECIMAL(12, 2),
            allowNull: true,
            field: 'estimated_cost_max'
        },
        expertCallRequested: {
            type: DataTypes.BOOLEAN,
            defaultValue: false,
            field: 'expert_call_requested'
        },
        expertCallScheduled: {
            type: DataTypes.DATE,
            allowNull: true,
            field: 'expert_call_scheduled'
        },
        notes: {
            type: DataTypes.TEXT,
            allowNull: true
        },
        cancellationReason: {
            type: DataTypes.TEXT,
            allowNull: true,
            field: 'cancellation_reason'
        },
        cancelledAt: {
            type: DataTypes.DATE,
            allowNull: true,
            field: 'cancelled_at'
        },
        cancelledBy: {
            type: DataTypes.UUID,
            allowNull: true,
            field: 'cancelled_by'
        },
        confirmedAt: {
            type: DataTypes.DATE,
            allowNull: true,
            field: 'confirmed_at'
        },
        completedAt: {
            type: DataTypes.DATE,
            allowNull: true,
            field: 'completed_at'
        }
    }, {
        tableName: 'bookings',
        timestamps: true,
        underscored: true,
        indexes: [{
                fields: ['user_id']
            },
            {
                fields: ['hospital_id']
            },
            {
                fields: ['treatment_id']
            },
            {
                fields: ['package_id']
            },
            {
                fields: ['status']
            },
            {
                fields: ['payment_status']
            },
            {
                fields: ['booking_date']
            },
            {
                fields: ['preferred_date']
            }
        ],
        comment: 'Patient booking records with complete workflow'
    });

    // ═══════════════════════════════════════════════════════════════════════════════
    // HOOKS - STATUS VALIDATION & BUSINESS LOGIC
    // ═══════════════════════════════════════════════════════════════════════════════

    // Validate status transitions
    Booking.addHook('beforeUpdate', (booking) => {
        if (booking.changed('status')) {
            const validTransitions = {
                'pending': ['confirmed', 'cancelled', 'rejected'],
                'confirmed': ['in_progress', 'cancelled'],
                'in_progress': ['completed', 'cancelled'],
                'completed': [],
                'cancelled': [],
                'rejected': []
            };

            const currentStatus = booking._previousDataValues.status;
            const newStatus = booking.status;

            if (!validTransitions[currentStatus] || !validTransitions[currentStatus].includes(newStatus)) {
                throw new Error(`Invalid status transition from ${currentStatus} to ${newStatus}`);
            }

            // Auto-set timestamps
            if (newStatus === 'confirmed') {
                booking.confirmedAt = new Date();
            } else if (newStatus === 'completed') {
                booking.completedAt = new Date();
            } else if (newStatus === 'cancelled') {
                booking.cancelledAt = new Date();
            }
        }
    });

    // Validate payment consistency
    Booking.addHook('beforeSave', (booking) => {
        if (booking.paidAmount > booking.totalAmount) {
            throw new Error('Paid amount cannot exceed total amount');
        }

        // Auto-update payment status
        if (booking.paidAmount === 0) {
            booking.paymentStatus = 'pending';
        } else if (booking.paidAmount > 0 && booking.paidAmount < booking.totalAmount) {
            booking.paymentStatus = 'partial';
        } else if (booking.paidAmount >= booking.totalAmount) {
            booking.paymentStatus = 'paid';
        }
    });

    // Validate email format
    Booking.addHook('beforeSave', (booking) => {
        if (booking.patientEmail && !booking.patientEmail.includes('@')) {
            throw new Error('Invalid email format');
        }
    });

    // ═══════════════════════════════════════════════════════════════════════════════
    // ASSOCIATIONS
    // ═══════════════════════════════════════════════════════════════════════════════

    Booking.associate = (models) => {
        Booking.belongsTo(models.User, {
            foreignKey: 'userId',
            as: 'user'
        });

        Booking.belongsTo(models.Hospital, {
            foreignKey: 'hospitalId',
            as: 'hospital'
        });

        Booking.belongsTo(models.Treatment, {
            foreignKey: 'treatmentId',
            as: 'treatment'
        });

        Booking.belongsTo(models.Package, {
            foreignKey: 'packageId',
            as: 'package'
        });

        Booking.hasMany(models.Payment, {
            foreignKey: 'bookingId',
            as: 'payments'
        });

        Booking.hasMany(models.Companion, {
            foreignKey: 'bookingId',
            as: 'companions'
        });

        Booking.hasMany(models.Document, {
            foreignKey: 'bookingId',
            as: 'documents'
        });
    };

    return Booking;
};