'use strict';

import { DataTypes } from 'sequelize';

// ═══════════════════════════════════════════════════════════════════════════════
// SETTINGS MODEL - ULTRA-COMPREHENSIVE - NO OPTIONAL CHAINING
// Production Ready with Proper Field Mapping
// ═══════════════════════════════════════════════════════════════════════════════

export default (sequelize) => {
    const Settings = sequelize.define('Settings', {
        settingId: {
            type: DataTypes.UUID,
            defaultValue: DataTypes.UUIDV4,
            primaryKey: true,
            field: 'setting_id'
        },
        settingType: {
            type: DataTypes.ENUM('system', 'payment', 'email', 'sms', 'notification', 'security', 'general'),
            allowNull: false,
            field: 'setting_type',
            comment: 'Type of setting configuration'
        },
        settingKey: {
            type: DataTypes.STRING(100),
            allowNull: false,
            unique: true,
            field: 'setting_key',
            comment: 'Unique key identifier'
        },
        settingValue: {
            type: DataTypes.TEXT,
            allowNull: true,
            field: 'setting_value',
            comment: 'Setting value (can be JSON, string, number)'
        },
        dataType: {
            type: DataTypes.ENUM('string', 'number', 'boolean', 'json', 'array'),
            defaultValue: 'string',
            field: 'data_type',
            comment: 'Data type of the value'
        },
        description: {
            type: DataTypes.TEXT,
            allowNull: true,
            comment: 'Description of what this setting controls'
        },
        isPublic: {
            type: DataTypes.BOOLEAN,
            defaultValue: false,
            field: 'is_public',
            comment: 'Whether this setting is accessible publicly'
        },
        isEditable: {
            type: DataTypes.BOOLEAN,
            defaultValue: true,
            field: 'is_editable',
            comment: 'Whether this setting can be modified'
        },
        validationRules: {
            type: DataTypes.JSONB,
            allowNull: true,
            field: 'validation_rules',
            comment: 'Validation rules for the setting value'
        },
        defaultValue: {
            type: DataTypes.TEXT,
            allowNull: true,
            field: 'default_value',
            comment: 'Default value if not set'
        },
        category: {
            type: DataTypes.STRING(100),
            allowNull: true,
            comment: 'Category grouping for settings'
        },
        displayOrder: {
            type: DataTypes.INTEGER,
            defaultValue: 0,
            field: 'display_order',
            comment: 'Order for displaying in UI'
        },
        createdBy: {
            type: DataTypes.UUID,
            allowNull: true,
            field: 'created_by'
        },
        updatedBy: {
            type: DataTypes.UUID,
            allowNull: true,
            field: 'updated_by'
        },
        version: {
            type: DataTypes.INTEGER,
            defaultValue: 1,
            comment: 'Version number for tracking changes'
        }
    }, {
        tableName: 'settings',
        timestamps: true,
        underscored: true,
        indexes: [{
                unique: true,
                fields: ['setting_type', 'setting_key']
            },
            {
                fields: ['setting_type']
            },
            {
                fields: ['category']
            },
            {
                fields: ['is_public']
            }
        ],
        comment: 'System-wide configuration settings'
    });

    // ═══════════════════════════════════════════════════════════════════════════════
    // HOOKS - VALIDATION & BUSINESS LOGIC
    // ═══════════════════════════════════════════════════════════════════════════════

    // Validate setting value based on data type
    Settings.addHook('beforeSave', (setting) => {
        if (setting.settingValue && setting.dataType) {
            switch (setting.dataType) {
                case 'number':
                    if (isNaN(setting.settingValue)) {
                        throw new Error('Setting value must be a valid number');
                    }
                    break;
                case 'boolean':
                    const validBooleans = ['true', 'false', '1', '0', 'yes', 'no'];
                    if (!validBooleans.includes(String(setting.settingValue).toLowerCase())) {
                        throw new Error('Setting value must be a valid boolean');
                    }
                    break;
                case 'json':
                    try {
                        JSON.parse(setting.settingValue);
                    } catch (e) {
                        throw new Error('Setting value must be valid JSON');
                    }
                    break;
                case 'array':
                    try {
                        const parsed = JSON.parse(setting.settingValue);
                        if (!Array.isArray(parsed)) {
                            throw new Error('Setting value must be a valid array');
                        }
                    } catch (e) {
                        throw new Error('Setting value must be a valid JSON array');
                    }
                    break;
            }
        }
    });

    // Prevent deletion of system-critical settings
    Settings.addHook('beforeDestroy', (setting) => {
        if (setting.isEditable === false) {
            throw new Error('Cannot delete system-critical settings');
        }
    });

    // Increment version on update
    Settings.addHook('beforeUpdate', (setting) => {
        if (setting.changed('settingValue')) {
            setting.version = setting.version + 1;
        }
    });

    // ═══════════════════════════════════════════════════════════════════════════════
    // ASSOCIATIONS
    // ═══════════════════════════════════════════════════════════════════════════════

    Settings.associate = (models) => {
        Settings.belongsTo(models.User, {
            foreignKey: 'createdBy',
            as: 'creator'
        });

        Settings.belongsTo(models.User, {
            foreignKey: 'updatedBy',
            as: 'updater'
        });
    };

    return Settings;
};