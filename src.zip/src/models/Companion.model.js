'use strict';

import { DataTypes } from 'sequelize';

// ═══════════════════════════════════════════════════════════════════════════════
// COMPANION MODEL - ULTRA-COMPREHENSIVE - NO OPTIONAL CHAINING
// Production Ready with Age Auto-Calculation
// ═══════════════════════════════════════════════════════════════════════════════

export default (sequelize) => {
    const Companion = sequelize.define('Companion', {
        companionId: {
            type: DataTypes.UUID,
            defaultValue: DataTypes.UUIDV4,
            primaryKey: true,
            field: 'companion_id',
            comment: 'Unique companion identifier'
        },
        bookingId: {
            type: DataTypes.UUID,
            allowNull: false,
            field: 'booking_id',
            references: {
                model: 'bookings',
                key: 'booking_id'
            },
            comment: 'Associated booking'
        },
        patientId: {
            type: DataTypes.UUID,
            allowNull: true,
            field: 'patient_id',
            references: {
                model: 'patients',
                key: 'patient_id'
            },
            comment: 'Patient being accompanied'
        },
        name: {
            type: DataTypes.STRING(100),
            allowNull: false,
            validate: {
                len: {
                    args: [2, 100],
                    msg: 'Name must be between 2 and 100 characters'
                }
            },
            comment: 'Companion full name'
        },
        relationship: {
            type: DataTypes.ENUM('spouse', 'parent', 'child', 'sibling', 'friend', 'relative', 'caretaker', 'other'),
            allowNull: false,
            comment: 'Relationship to patient'
        },
        age: {
            type: DataTypes.INTEGER,
            allowNull: true,
            validate: {
                min: 0,
                max: 150
            },
            comment: 'Companion age (auto-calculated from DOB)'
        },
        dateOfBirth: {
            type: DataTypes.DATE,
            allowNull: true,
            field: 'date_of_birth',
            comment: 'Date of birth for age calculation'
        },
        gender: {
            type: DataTypes.ENUM('male', 'female', 'other'),
            allowNull: true,
            comment: 'Companion gender'
        },
        email: {
            type: DataTypes.STRING(255),
            allowNull: true,
            validate: {
                isEmail: {
                    msg: 'Must be a valid email address'
                }
            },
            comment: 'Contact email'
        },
        phone: {
            type: DataTypes.STRING(20),
            allowNull: false,
            validate: {
                is: {
                    args: /^[+]?[0-9]{10,15}$/,
                    msg: 'Invalid phone number format'
                }
            },
            comment: 'Contact phone number'
        },
        alternatePhone: {
            type: DataTypes.STRING(20),
            allowNull: true,
            field: 'alternate_phone',
            comment: 'Alternative contact number'
        },
        emergencyContact: {
            type: DataTypes.STRING(20),
            allowNull: true,
            field: 'emergency_contact',
            comment: 'Emergency contact number'
        },
        idType: {
            type: DataTypes.ENUM('passport', 'drivers_license', 'national_id', 'voter_id', 'aadhaar', 'pan', 'other'),
            allowNull: true,
            field: 'id_type',
            comment: 'Type of identification document'
        },
        idNumber: {
            type: DataTypes.STRING(100),
            allowNull: true,
            field: 'id_number',
            comment: 'ID document number'
        },
        idDocumentUrl: {
            type: DataTypes.TEXT,
            allowNull: true,
            field: 'id_document_url',
            comment: 'URL to uploaded ID document'
        },
        address: {
            type: DataTypes.TEXT,
            allowNull: true,
            comment: 'Residential address'
        },
        city: {
            type: DataTypes.STRING(100),
            allowNull: true,
            comment: 'City of residence'
        },
        state: {
            type: DataTypes.STRING(100),
            allowNull: true,
            comment: 'State/Province'
        },
        country: {
            type: DataTypes.STRING(100),
            allowNull: true,
            comment: 'Country of residence'
        },
        zipCode: {
            type: DataTypes.STRING(20),
            allowNull: true,
            field: 'zip_code',
            comment: 'Postal/ZIP code'
        },
        nationality: {
            type: DataTypes.STRING(100),
            allowNull: true,
            comment: 'Nationality'
        },
        passportNumber: {
            type: DataTypes.STRING(50),
            allowNull: true,
            field: 'passport_number',
            comment: 'Passport number for international travel'
        },
        passportExpiry: {
            type: DataTypes.DATE,
            allowNull: true,
            field: 'passport_expiry',
            comment: 'Passport expiration date'
        },
        visaRequired: {
            type: DataTypes.BOOLEAN,
            defaultValue: false,
            field: 'visa_required',
            comment: 'Whether visa is required'
        },
        visaStatus: {
            type: DataTypes.ENUM('not_required', 'pending', 'approved', 'rejected', 'expired'),
            defaultValue: 'not_required',
            field: 'visa_status',
            comment: 'Visa application status'
        },
        medicalConditions: {
            type: DataTypes.JSONB,
            allowNull: true,
            defaultValue: [],
            field: 'medical_conditions',
            comment: 'Any medical conditions companion has'
        },
        specialRequirements: {
            type: DataTypes.TEXT,
            allowNull: true,
            field: 'special_requirements',
            comment: 'Special needs or requirements'
        },
        travelPreferences: {
            type: DataTypes.JSONB,
            allowNull: true,
            field: 'travel_preferences',
            comment: 'Travel preferences (seat, meal, etc)'
        },
        accommodationPreferences: {
            type: DataTypes.JSONB,
            allowNull: true,
            field: 'accommodation_preferences',
            comment: 'Accommodation preferences'
        },
        dietaryRestrictions: {
            type: DataTypes.JSONB,
            allowNull: true,
            defaultValue: [],
            field: 'dietary_restrictions',
            comment: 'Dietary restrictions or preferences'
        },
        allergies: {
            type: DataTypes.JSONB,
            allowNull: true,
            defaultValue: [],
            comment: 'Known allergies'
        },
        medications: {
            type: DataTypes.JSONB,
            allowNull: true,
            defaultValue: [],
            comment: 'Current medications'
        },
        insuranceProvider: {
            type: DataTypes.STRING(255),
            allowNull: true,
            field: 'insurance_provider',
            comment: 'Travel insurance provider'
        },
        insurancePolicyNumber: {
            type: DataTypes.STRING(100),
            allowNull: true,
            field: 'insurance_policy_number',
            comment: 'Insurance policy number'
        },
        insuranceExpiry: {
            type: DataTypes.DATE,
            allowNull: true,
            field: 'insurance_expiry',
            comment: 'Insurance expiration date'
        },
        isPrimaryContact: {
            type: DataTypes.BOOLEAN,
            defaultValue: false,
            field: 'is_primary_contact',
            comment: 'Primary contact person for patient'
        },
        canMakeDecisions: {
            type: DataTypes.BOOLEAN,
            defaultValue: false,
            field: 'can_make_decisions',
            comment: 'Authorized to make medical decisions'
        },
        isPowerOfAttorney: {
            type: DataTypes.BOOLEAN,
            defaultValue: false,
            field: 'is_power_of_attorney',
            comment: 'Has power of attorney'
        },
        notes: {
            type: DataTypes.TEXT,
            allowNull: true,
            comment: 'Additional notes'
        }
    }, {
        tableName: 'companions',
        timestamps: true,
        underscored: true,
        indexes: [{
                fields: ['booking_id']
            },
            {
                fields: ['patient_id']
            },
            {
                fields: ['relationship']
            },
            {
                fields: ['is_primary_contact']
            }
        ],
        comment: 'Travel companions and patient attendants'
    });

    // ═══════════════════════════════════════════════════════════════════════════════
    // HOOKS - AUTO-CALCULATE AGE & VALIDATIONS
    // ═══════════════════════════════════════════════════════════════════════════════

    // Auto-calculate age from date of birth
    Companion.addHook('beforeSave', (companion) => {
        if (companion.dateOfBirth) {
            const today = new Date();
            const birthDate = new Date(companion.dateOfBirth);
            let age = today.getFullYear() - birthDate.getFullYear();
            const monthDiff = today.getMonth() - birthDate.getMonth();

            if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < birthDate.getDate())) {
                age--;
            }

            companion.age = age;
        }
    });

    // Validate email format
    Companion.addHook('beforeSave', (companion) => {
        if (companion.email && !companion.email.includes('@')) {
            throw new Error('Invalid email format');
        }
    });

    // Validate passport expiry for international travel
    Companion.addHook('beforeSave', (companion) => {
        if (companion.passportExpiry) {
            const expiryDate = new Date(companion.passportExpiry);
            const today = new Date();
            const sixMonthsFromNow = new Date(today.setMonth(today.getMonth() + 6));

            if (expiryDate < sixMonthsFromNow) {
                console.warn(`Passport expiring soon for companion: ${companion.name}`);
            }
        }
    });

    // Validate age range
    Companion.addHook('beforeSave', (companion) => {
        if (companion.age && (companion.age < 0 || companion.age > 150)) {
            throw new Error('Age must be between 0 and 150');
        }
    });

    // ═══════════════════════════════════════════════════════════════════════════════
    // ASSOCIATIONS
    // ═══════════════════════════════════════════════════════════════════════════════

    Companion.associate = (models) => {
        Companion.belongsTo(models.Booking, {
            foreignKey: 'bookingId',
            as: 'booking'
        });

        Companion.belongsTo(models.Patient, {
            foreignKey: 'patientId',
            as: 'patient'
        });
    };

    return Companion;
};